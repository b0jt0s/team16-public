//1. érték: Csapat neve (nev)
//2. érték: Csapat helyezése (helyezes)
//3. érték: Csapat helyének változása (valtozas)
//4. érték: Csapat Pontszama (pont)

const csapatAdat = [
    "Anglia;4;0;1662",
    "Argentína;10;0;1614",
    "Belgium;1;0;1752",
    "Brazília;3;-1;1719",
    "Chile;17;-3;1576",
    "Dánia;14;-1;1584",
    "Franciaország;2;1;1725",
    "Hollandia;13;3;1586",
    "Horvátország;8;-1;1625",
    "Kolumbia;9;-1;1622",
    "Mexikó;12;0;1603",
    "Németország;16;-1;1580",
    "Olaszország;15;1;1583",
    "Peru;19;0;1551",
    "Portugália;5;1;1643",
    "Spanyolország;7;2;1631",
    "Svájc;11;0;1604",
    "Svédország;18;0;1560",
    "Szenegál;20;0;1546",
    "Uruguay;6;-1;1639"
];

interface FifaAdat {
    nev: string;
    helyezes: number;
    valtozas: number;
    pont: number;
}

//Adatok beolvasása objektum típusú tömbbe:
function ObjektumFeltolto(feltoltendoElem: string[]): FifaAdat[] {
    let beolvasottAdatok: FifaAdat[] = [];
    for (let i: number = 0; i < feltoltendoElem.length; i++) {
        let daraboltAdatok = feltoltendoElem[i].split(";");
        let ujCsapat: FifaAdat = {
            nev: daraboltAdatok[0],
            helyezes: Number(daraboltAdatok[1]),
            valtozas: Number(daraboltAdatok[2]),
            pont: Number(daraboltAdatok[3]),
        }
        beolvasottAdatok.push(ujCsapat);
    }
    return beolvasottAdatok;
}

const fifaAdatok = ObjektumFeltolto(csapatAdat);
//Konzol felületre kiíratása a létrehozott objektum típusú tömbnek
console.log(fifaAdatok);

/**
    //Táblázatban megjelenítése a létrehozott objektum típusú tömbnek
    function FifaAdatokKiir(megjelenitendoAdatok) {
        document.write("<table border='1'><caption>FifaAdatok</caption>");
        document.write("<tr><th>Ország neve</th><th>Helyezése</th><th>Változás</th><th>Pontszám</th></tr>");
        for (let i = 0; i < megjelenitendoAdatok.length; i++) {
            document.write(`<tr><td>${megjelenitendoAdatok[i].nev}</td><td>${megjelenitendoAdatok[i].helyezes}</td><td>${megjelenitendoAdatok[i].valtozas}</td><td>${megjelenitendoAdatok[i].pontszam}</td></tr>`);
        } document.write("</table>");
    }
    FifaAdatokKiir(fifaAdatok);
*/

//F01 - Adja meg aktuálisan hány csapat szerepel a ranglistán
function CsapatokSzama(vizsgaltTomb: FifaAdat[]): number {
    return vizsgaltTomb.length;
}
function CsapatokSzamaKiir(csapatokSzama: number) {
    console.log("1. feladat");
    console.log("Az adatokban lévő csapatok száma:", csapatokSzama);
}
CsapatokSzamaKiir(CsapatokSzama(fifaAdatok))

//F02 - Írja ki mennyi a résztvevő csapatok átlagpontszáma.
function AtlagPontszam(vizsgaltTomb: FifaAdat[]): number {
    let osszPontszam: number = 0;
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        osszPontszam += vizsgaltTomb[i].pont;
    }
    return osszPontszam / vizsgaltTomb.length;
}
function AtlagPontszamKiir(atlagPontszam: number) {
    console.log("2. feladat");
    console.log("Az adatokban lévő csapatok átlagos pontszáma:", atlagPontszam);
}
AtlagPontszamKiir(AtlagPontszam(fifaAdatok));


//F03 - Listázza ki azokat a csapatokat, akik az átlagnál több pontot értek el!
function AtlagFelettiek(vizsgaltTomb: FifaAdat[]): string[] {
    let atlagFelettiek: string[] = [];
    let atlagPontszam: number = AtlagPontszam(vizsgaltTomb);
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].pont > atlagPontszam) {
            let ujElem: any = {}
            ujElem.nev = vizsgaltTomb[i].nev;
            ujElem.pont = vizsgaltTomb[i].pont;
            atlagFelettiek.push(ujElem);
        }
    }
    return atlagFelettiek;
}

//Fejlesztési lehetőség:az eredményeket táblázatos formában jelenítse meg
function AtlagFelettiekKiir(megjelenitendoAdatok: any): any {
    console.log("3. feladat");
    console.log("Ország neve / Pontszám");
    for (let i: number = 0; i < megjelenitendoAdatok.length; i++) {
        console.log(megjelenitendoAdatok[i].nev + "/" + megjelenitendoAdatok[i].pont);
    }
}
AtlagFelettiekKiir(AtlagFelettiek(fifaAdatok));

//F04 - Írja ki a legtöbbet javító csapat adatait: Helyezés, CsapatNeve, Pontszáma
//Maximum keresés index alapon
function LegtobbetJavito(vizsgaltTomb: FifaAdat[]): number {
    let legnagyobbJavitas: number = 0;
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].valtozas > vizsgaltTomb[legnagyobbJavitas].valtozas) {
            legnagyobbJavitas = i;
        }
    }
    return legnagyobbJavitas;//Index értéket ad vissza!
}
function LegtobbetJavitoKiir(csapatIndexe: number) {
    console.log("4. feladat");
    console.log("A legtöbbet javító csapat helyzése:", fifaAdatok[csapatIndexe].helyezes);
    console.log("A legtöbbet javító csapat neve:", fifaAdatok[csapatIndexe].nev);
    console.log("A legtöbbet javító csapat pontszáma:", fifaAdatok[csapatIndexe].pont);
}
LegtobbetJavitoKiir(LegtobbetJavito(fifaAdatok));

//F05 - Határozza meg az adatok közöt megtalálható-e Magyarország csapata!
function SzerepelEMagyarorszag(vizsgaltTomb: FifaAdat[]): boolean {
    let szerepelE: boolean = false;
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].nev == "Magyarország") {
            szerepelE = true;//return true;
        }
    }
    return szerepelE;;//return false;
}
function SzerepelEMagyarorszagKiir(szerepelE: boolean) {
    console.log("5. feladat");
    if (szerepelE == true) {
        console.log("A csapatok között a ranglistán szerepel Magyarország");
    }
    else {
        console.log("A csapatok között a ranglistán NEM szerepel Magyarország");
    }
}
SzerepelEMagyarorszagKiir(SzerepelEMagyarorszag(fifaAdatok));

//Fejlesztési lehetőség: Bármely csapatot megnézni, szerepelt-e a listán
function SzerepelEUniverzalis(vizsgaltTomb: FifaAdat[], orszagNeve: string): boolean {
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].nev == orszagNeve) {
            return true;
        }
    }
    return false;
}

function SzerepelEUniverzalisKiir(szerepelE: boolean, orszagNeve: string) {
    console.log("5. feladat (Fejlesztett)");
    if (szerepelE == true) {
        console.log("A csapatok között a ranglistán szerepel ", orszagNeve);
    }
    else {
        console.log("A csapatok között a ranglistán NEM szerepel ", orszagNeve);
    }
}
SzerepelEUniverzalisKiir(SzerepelEUniverzalis(fifaAdatok, "Brazília"), "Brazília");
SzerepelEUniverzalisKiir(SzerepelEUniverzalis(fifaAdatok, "Olaszország"), "Olaszország");

//F06 - Készítsen  statisztikát  a  helyezések  változása  (Valtozas)  alapján  csoportosítva  a  csapatok számáról  a  minta  szerint!  Csak  azok  a  helyezésváltozások  jelenjenek  meg  a  képernyőn, amelyek esetében a csapatok száma több mint egy volt! A megjelenő csoportok sorrendje tetszőleges.
function ValtozasKivalogato(vizsgaltTomb: FifaAdat[]): [string, number] {
    let valtozasLista: [string, number] = ['', 0];
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        let szerepelE: boolean = false;
        for (let j: number = 0; j < valtozasLista.length; j++) {
            if (valtozasLista[j] == vizsgaltTomb[i].valtozas) {
                szerepelE = true;
            }
        }
        if (szerepelE == false) {
            valtozasLista.push(vizsgaltTomb[i].valtozas);
        }
    }
    return valtozasLista;
}
let valtozasTipusok = ValtozasKivalogato(fifaAdatok);

function ValtozasMegszamolo(vizsgaltTomb: FifaAdat[], valtozasLista: [string, number]) {
    let valtozasMennyiseg: number[] = [];
    for (let i: number = 0; i < valtozasLista.length; i++) {
        valtozasMennyiseg.push(0);
    }

    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        for (let j: number = 0; j < valtozasLista.length; j++) {
            if (valtozasLista[j] == vizsgaltTomb[i].valtozas) {
                valtozasMennyiseg[j]++;
            }
        }
    }
    return valtozasMennyiseg;
}
let valtozasTipusokMennyisege = ValtozasMegszamolo(fifaAdatok, valtozasTipusok)

//Fejlesztési lehetőség:az eredményeket táblázatos formában jelenítse meg
function StatisztikaTablazatGenerator(valtozasok, valtozasMennyisegek) {
    console.log("6. feladat");
    console.log("Változás mértéke / Változás mennyisége");
    for (let i: number = 0; i < valtozasok.length; i++) {
        if (valtozasMennyisegek[i] > 1) {//Itt szűröm, hogy csak adott mennyiség felett jelenjen meg!
            console.log(valtozasok[i] + " / " + valtozasMennyisegek[i])
        }
    }
}

StatisztikaTablazatGenerator(valtozasTipusok, valtozasTipusokMennyisege);