//1. érték: Csapat neve (nev)
//2. érték: Csapat helyezése (helyezes)
//3. érték: Csapat helyének változása (valtozas)
//4. érték: Csapat Pontszama (pont)

const csapatAdat = [
    "Anglia;4;0;1662",
    "Argentína;10;0;1614",
    "Belgium;1;0;1752",
    "Brazília;3;-1;1719",
    "Chile;17;-3;1576",
    "Dánia;14;-1;1584",
    "Franciaország;2;1;1725",
    "Hollandia;13;3;1586",
    "Horvátország;8;-1;1625",
    "Kolumbia;9;-1;1622",
    "Mexikó;12;0;1603",
    "Németország;16;-1;1580",
    "Olaszország;15;1;1583",
    "Peru;19;0;1551",
    "Portugália;5;1;1643",
    "Spanyolország;7;2;1631",
    "Svájc;11;0;1604",
    "Svédország;18;0;1560",
    "Szenegál;20;0;1546",
    "Uruguay;6;-1;1639"
];
//Adatok beolvasása objektum típusú tömbbe:
function ObjektumFeltolto(feltoltendoElem) {
    const beolvasottAdatok = [];
    for (let i = 0; i < feltoltendoElem.length; i++) {
        let objektum = {};
        let daraboltAdatSor = feltoltendoElem[i].split(";");
        objektum.nev = daraboltAdatSor[0];
        objektum.helyezes = Number(daraboltAdatSor[1]);
        objektum.valtozas = Number(daraboltAdatSor[2]);
        objektum.pontszam = Number(daraboltAdatSor[3]);
        beolvasottAdatok.push(objektum);
    }
    return beolvasottAdatok;
}
const fifaAdatok = ObjektumFeltolto(csapatAdat);
//Konzol felületre kiíratása a létrehozott objektum típusú tömbnek
console.log(fifaAdatok);

//Táblázatban megjelenítése a létrehozott objektum típusú tömbnek
function FifaAdatokKiir(megjelenitendoAdatok) {
    document.write("<table border='1'><caption>FifaAdatok</caption>");
    document.write("<tr><th>Ország neve</th><th>Helyezése</th><th>Változás</th><th>Pontszám</th></tr>");
    for (let i = 0; i < megjelenitendoAdatok.length; i++) {
        document.write(`<tr><td>${megjelenitendoAdatok[i].nev}</td><td>${megjelenitendoAdatok[i].helyezes}</td><td>${megjelenitendoAdatok[i].valtozas}</td><td>${megjelenitendoAdatok[i].pontszam}</td></tr>`);
    } document.write("</table>");
}
FifaAdatokKiir(fifaAdatok);

//F01 - Adja meg aktuálisan hány csapat szerepel a ranglistán

function CsapatokSzama(vizsgaltTomb) {
    return vizsgaltTomb.length;
}
function CsapatokSzamaKiir(csapatokSzama) {
    document.write("<hr>1. feladat<br>");
    document.write("Az adatokban lévő csapatok száma:", csapatokSzama);
}
CsapatokSzamaKiir(CsapatokSzama(fifaAdatok))

//F02 - Írja ki mennyi a résztvevő csapatok átlagpontszáma. 
function AtlagPontszam(vizsgaltTomb) {
    let osszPontszam = 0;
    for (let i = 0; i < vizsgaltTomb.length; i++) {
        osszPontszam += vizsgaltTomb[i].pontszam;
    }
    return osszPontszam / vizsgaltTomb.length;
}
function AtlagPontszamKiir(atlagPontszam) {
    document.write("<hr>2. feladat<br>");
    document.write("Az adatokban lévő csapatok átlagos pontszáma:", atlagPontszam);
}
AtlagPontszamKiir(AtlagPontszam(fifaAdatok));


//F03 - Listázza ki azokat a csapatokat, akik az átlagnál több pontot értek el!
function AtlagFelettiek(vizsgaltTomb) {
    let atlagFelettiek = [];
    let atlagPontszam = AtlagPontszam(vizsgaltTomb);
    for (let i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].pontszam > atlagPontszam) {
            let ujElem = {}
            ujElem.nev = vizsgaltTomb[i].nev;
            ujElem.pontszam = vizsgaltTomb[i].pontszam;
            atlagFelettiek.push(ujElem);
        }
    }
    return atlagFelettiek;
}


//Fejlesztési lehetőség:az eredményeket táblázatos formában jelenítse meg
function AtlagFelettiekKiir(megjelenitendoAdatok) {
    document.write("<hr>3. feladat<br>");
    document.write("<table border='1'><caption>Átlag felettiek</caption>");
    document.write("<tr><th>Ország neve</th><th>Pontszám</th></tr>");
    for (let i = 0; i < megjelenitendoAdatok.length; i++) {
        document.write(`<tr><td>${megjelenitendoAdatok[i].nev}</td><td>${megjelenitendoAdatok[i].pontszam}</td></tr>`);
    } document.write("</table>");
}
AtlagFelettiekKiir(AtlagFelettiek(fifaAdatok));

//F04 - Írja ki a legtöbbet javító csapat adatait: Helyezés, CsapatNeve, Pontszáma
//Maximum keresés index alapon
function LegtobbetJavito(vizsgaltTomb) {
    let legnagyobbJavitas = 0;
    for (let i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].valtozas > vizsgaltTomb[legnagyobbJavitas].valtozas) {
            legnagyobbJavitas = i;
        }
    }
    return legnagyobbJavitas;//Index értéket ad vissza!
}
function LegtobbetJavitoKiir(csapatIndexe) {
    document.write("<hr>4. feladat<br>");
    document.write("<br>A legtöbbet javító csapat helyzése:", fifaAdatok[csapatIndexe].helyezes);
    document.write("<br>A legtöbbet javító csapat neve:", fifaAdatok[csapatIndexe].nev);
    document.write("<br>A legtöbbet javító csapat pontszáma:", fifaAdatok[csapatIndexe].pontszam);
}
LegtobbetJavitoKiir(LegtobbetJavito(fifaAdatok));

//F05 - Határozza meg a adatok közöt megtalálható-e Magyarország csapata!
function SzerepelEMagyarorszag(vizsgaltTomb) {
    let szerepelE = false;
    for (let i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].nev == "Magyarország") {
            szerepelE = true;//return true;
        }
    }
    return szerepelE;;//return false;
}
function SzerepelEMagyarorszagKiir(szerepelE) {
    document.write("<hr>5. feladat<br>");
    if (szerepelE == true) {
        document.write("A csapatok között a ranglistán szerepel Magyarország");
    }
    else {
        document.write("A csapatok között a ranglistán NEM szerepel Magyarország");
    }
}
SzerepelEMagyarorszagKiir(SzerepelEMagyarorszag(fifaAdatok));

//Fejlesztési lehetőség: Bármely csapatot megnézni, szerepelt-e a listán

function SzerepelEUniverzalis(vizsgaltTomb, orszagNeve) {
    for (let i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].nev == orszagNeve) {
            return true;
        }
    }
    return false;
}

function SzerepelEUniverzalisKiir(szerepelE, orszagNeve) {
    document.write("<hr>5. feladat(Fejlesztett)<br>");
    if (szerepelE == true) {
        document.write("A csapatok között a ranglistán szerepel ", orszagNeve);
    }
    else {
        document.write("A csapatok között a ranglistán NEM szerepel ", orszagNeve);
    }
}
SzerepelEUniverzalisKiir(SzerepelEUniverzalis(fifaAdatok, "Brazília"), "Brazília");
SzerepelEUniverzalisKiir(SzerepelEUniverzalis(fifaAdatok, "Olaszország"), "Olaszország");


//F06 - Készítsen  statisztikát  a  helyezések  változása  (Valtozas)  alapján  csoportosítva  a  csapatok számáról  a  minta  szerint!  Csak  azok  a  helyezésváltozások  jelenjenek  meg  a  képernyőn, amelyek esetében a csapatok száma több mint egy volt! A megjelenő csoportok sorrendje tetszőleges.


function ValtozasKivalogato(vizsgaltTomb) {
    let valtozasLista = [];
    for (let i = 0; i < vizsgaltTomb.length; i++) {
        let szerepelE = false;
        for (let j = 0; j < valtozasLista.length; j++) {
            if (valtozasLista[j] == vizsgaltTomb[i].valtozas) {
                szerepelE = true;
            }
        }
        if (szerepelE == false) {
            valtozasLista.push(vizsgaltTomb[i].valtozas);
        }
    }
    return valtozasLista;
}
let valtozasTipusok = ValtozasKivalogato(fifaAdatok);

function ValtozasMegszamolo(vizsgaltTomb, valtozasLista) {
    let valtozasMennyiseg = [];
    for (let i = 0; i < valtozasLista.length; i++) {
        valtozasMennyiseg.push(0);
    }

    for (let i = 0; i < vizsgaltTomb.length; i++) {
        for (let j = 0; j < valtozasLista.length; j++) {
            if (valtozasLista[j] == vizsgaltTomb[i].valtozas) {
                valtozasMennyiseg[j]++;
            }
        }
    }
    return valtozasMennyiseg;
}
let valtozasTipusokMennyisege = ValtozasMegszamolo(fifaAdatok, valtozasTipusok)

//Fejlesztési lehetőség:az eredményeket táblázatos formában jelenítse meg
function StatisztikaTablazatGenerator(valtozasok, valtozasMennyisegek) {
    document.write("<hr>6. feladat<br>");
    document.write("<table border='1'><caption>Változások</caption>");
    document.write("<tr><th>Változás mértéke</th><th>Változás mennyisége</th></tr>");
    for (let i = 0; i < valtozasok.length; i++) {
        if (valtozasMennyisegek[i] > 1) {//Itt szűröm, hogy csak adott mennyiség felett jelenjen meg!
            document.write(`<tr><td>${valtozasok[i]}</td><td>${valtozasMennyisegek[i]}</td></tr>`)
        }
    }
    document.write("</table>");
}

StatisztikaTablazatGenerator(valtozasTipusok, valtozasTipusokMennyisege);